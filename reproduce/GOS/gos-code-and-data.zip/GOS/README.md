# Reproducing Geographically Optimal Similarity (GOS)

Companion code for the tutorial at
<https://yongzesong.com/reproduce/GOS/gos.html>

Method: Song, Y. (2022). Geographically Optimal Similarity.
*Mathematical Geosciences* 55, 295-320. doi:10.1007/s11004-022-10036-8

Implementation: the CRAN package `geosimilarity` (3.9), by Yongze Song and
Wenbo Lyu, which supplies `gos()`, `gos_bestkappa()` and `removeoutlier()`.

## Run it

```r
install.packages("geosimilarity")   # the only requirement beyond base R
```

```bash
Rscript run-all.R test     # 42 verification checks, about 40 s
Rscript run-all.R          # the whole pipeline, about 107 s on one core
Rscript run-all.R 30 40    # re-run single steps (10 20 30 40 50 90)
```

Run from the folder root, i.e. the directory holding `run-all.R`. Every step
reads what the previous step wrote, so a single step can be re-run after a
change in `config/project-config.R` without repeating the rest.

`config/project-config.R` is the only file you need to edit.

## What is in this archive

```
run-all.R                  entry point
config/project-config.R    the only file to edit
R/                         00-config, 01-helpers, then steps 10, 20, 30, 40, 50, 90
tests/                     test-01 method properties (18 checks)
                           test-02 committed results regenerate (24 checks)
results/                   the CSVs every number in the tutorial is quoted from
tables/                    LaTeX versions of the same tables
env/                       requirements.md, runtimes.csv, session-info.txt
```

## What is NOT in this archive, and why

- **`data/`.** Both input tables — the 894 Zn samples and the 13,132-cell 1 km
  prediction grid — ship inside the `geosimilarity` package itself, as
  `data(zn)` and `data(grid)`. `R/10-prepare-data.R` loads them from the
  package and writes verbatim CSV copies into `data/`, so the inputs appear on
  disk the first time you run the pipeline. Nothing is downloaded.
- **The two grid-prediction CSVs** (`results/grid-prediction.csv` and
  `results/grid-prediction-bcs.csv`, about 1.5 MB each). Step 40 regenerates
  both in about 10 seconds.
- **`figs/`.** Every figure is redrawn by the step that owns it, as a PNG and a
  matching vector PDF. The rendered figures are on the tutorial page.

## Reference

- Package: <https://cran.r-project.org/package=geosimilarity>
- Vignette: <https://cran.r-project.org/web/packages/geosimilarity/vignettes/geosimilarity.html>
- Online calculator (no installation): <https://yongzesong.com/app/gos/>
