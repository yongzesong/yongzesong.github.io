library(caret)   # Framework for model training and cross-validation
library(mgcv)    # GAM implementation used internally by caret

# ------------------------------------------------------------
# Prepare non-spatial data by removing geometry column
# ------------------------------------------------------------
df <- sf::st_drop_geometry(d24)

# ------------------------------------------------------------
# Define 5-fold cross-validation strategy
# ------------------------------------------------------------
ctrl <- trainControl(
  method = "cv",     # k-fold cross-validation
  number = 5         # number of folds
)

# ------------------------------------------------------------
# Train a Generalized Additive Model (GAM) using caret
# Smooth terms are handled internally by caret/mgcv
# ------------------------------------------------------------
model_caret_gam <- train(
  burned ~ pre + tem,   # response and predictors
  data = df,            # training data
  method = "gam",       # GAM model (mgcv::gam backend)
  trControl = ctrl      # cross-validation control
)

# Print cross-validated model performance and summary
model_caret_gam

# ------------------------------------------------------------
# Plot 1D smooth effects of predictors from the fitted GAM
# ------------------------------------------------------------
plot(model_caret_gam$finalModel, pages = 1, shade = TRUE)



library(plotly)   # Interactive 3D visualisation library

# ------------------------------------------------------------
# Create a regular grid of predictor values for surface plotting
# ------------------------------------------------------------
grid <- expand.grid(
  pre = seq(min(df$pre), max(df$pre), length.out = 50),  # precipitation range
  tem = seq(min(df$tem), max(df$tem), length.out = 50)   # temperature range
)

# ------------------------------------------------------------
# Predict GAM response over the grid
# ------------------------------------------------------------
grid$burned_hat <- predict(
  model_caret_gam$finalModel,   # fitted GAM model
  newdata = grid                # prediction grid
)

# ------------------------------------------------------------
# Reshape predictions into a matrix required for surface plotting
# ------------------------------------------------------------
z_mat <- matrix(
  grid$burned_hat,
  nrow = 50,
  ncol = 50
)

# ------------------------------------------------------------
# Interactive 3D surface plot of GAM response
# ------------------------------------------------------------
plot_ly(
  x = unique(grid$pre),    # x-axis: precipitation
  y = unique(grid$tem),    # y-axis: temperature
  z = z_mat,               # z-axis: predicted burned area
  type = "surface"
) %>%
  layout(
    scene = list(
      xaxis = list(title = "pre"),
      yaxis = list(title = "tem"),
      zaxis = list(title = "burned")
    ),
    title = "Interactive GAM Response Surface"
  )
