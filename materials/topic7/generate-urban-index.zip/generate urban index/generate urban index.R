setwd()

###############################################################################
# 1) Load required functions and input data
###############################################################################
# Source entropy-weighting and normalisation functions
source("./entropyweight.R")

# Read urban indicator data
dt <- read.csv("urbanvars.csv")


###############################################################################
# 2) Separate variables into two groups
#    vars1: main socioeconomic / urban development indicators
#    vars2: supplementary indicators
###############################################################################
vars1 <- dt[, 2:8]
vars2 <- dt[, 9:10]


###############################################################################
# 3) Normalise variables
#    direction = 1 indicates that all variables are positively oriented
#    (higher values indicate higher level of urbanisation)
###############################################################################
normlize.vars1 <- normalize(vars1, direction = rep(1, 7))
normlize.vars2 <- normalize(vars2, direction = rep(1, 2))


###############################################################################
# 4) Calculate entropy weights for each variable group
#    Entropy weighting assigns higher weights to variables with greater
#    information content (higher variability)
###############################################################################
w1 <- entropyweight(normlize.vars1)
w1

w2 <- entropyweight(normlize.vars2)
w2


###############################################################################
# 5) Calculate weighted composite scores for each group
#    z1: composite score from vars1
#    z2: composite score from vars2
###############################################################################
z1 <- colSums(t(normlize.vars1) * w1)
z2 <- colSums(t(normlize.vars2) * w2)


###############################################################################
# 6) Construct final urbanisation index
#    The final index is the average of the two composite scores
###############################################################################
urban <- (z1 + z2) / 2

urbanindex <- data.frame(
  "PID" = dt$PID,
  urban
)


###############################################################################
# 7) Load spatial packages and prepare spatial data
###############################################################################
library(sf)
library(dplyr)
library(ggplot2)
library(patchwork)
library(scales)

# Read study area shapefile and standardise PID type
sa <- st_read("studyarea.shp", quiet = TRUE) %>%
  mutate(PID = as.character(PID))

# Standardise PID type in urban index table
sp.urbanindex <- urbanindex %>%
  mutate(PID = as.character(PID))


###############################################################################
# 8) Join urban index to spatial polygons
###############################################################################
sa2 <- sa %>%
  left_join(sp.urbanindex %>% select(PID, urban), by = "PID")


###############################################################################
# 9) Visualise spatial distribution of the urbanisation index
#    A diverging colour scale (blue–white–red) highlights low, medium,
#    and high levels of urbanisation
###############################################################################
ggplot(sa2) +
  geom_sf(aes(fill = urban), color = "gray60", linewidth = 0.1) +
  scale_fill_gradient2(
    low = "blue",
    mid = "white",
    high = "red",
    midpoint = median(sa2$urban, na.rm = TRUE),
    limits = range(sa2$urban, na.rm = TRUE),
    na.value = "grey90"
  ) +
  theme_bw()


