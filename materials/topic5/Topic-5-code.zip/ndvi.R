###############################################################################
# Spatial stratified random sampling example for remote sensing images (R)
# - Creates synthetic multi-band image (3 bands) + a land-cover strata raster
# - Draws stratified random samples (equal n per class)
# - Extracts image values at samples and summarizes by class
###############################################################################

# Packages
library(terra)
library(dplyr)
library(ggplot2)

set.seed(123)

###############################################################################
# 1) Create synthetic "remote sensing image" (3 bands) with NDVI engineered
#    to have MORE pixels in class 1 (<0.10) and class 4 (>0.45)
###############################################################################

# Define a study area raster grid
r0 <- rast(ncols = 200, nrows = 200, xmin = 0, xmax = 2000, ymin = 0, ymax = 2000)

# Create spatial coordinate rasters (for smooth gradients)
xy <- crds(r0, df = TRUE)
xmat <- matrix(xy[,1], nrow = nrow(r0), ncol = ncol(r0), byrow = FALSE)
ymat <- matrix(xy[,2], nrow = nrow(r0), ncol = ncol(r0), byrow = FALSE)

# Two spatial "bumps": one water-like (low NDVI), one forest-like (high NDVI)
water_bump  <- exp(-((xmat - 600)^2  + (ymat - 1500)^2) / (2 * 350^2))
forest_bump <- exp(-((xmat - 1500)^2 + (ymat - 600)^2)  / (2 * 450^2))

# NDVI surface: base + forest - water + noise
ndvi_mat <- 0.30 + 0.55 * forest_bump - 0.45 * water_bump +
  matrix(rnorm(ncell(r0), 0, 0.03), nrow = nrow(r0), ncol = ncol(r0))

# Clamp NDVI to a realistic range
ndvi_mat <- pmax(-0.2, pmin(0.85, ndvi_mat))

# Create a brightness (sum) field so bands look like reflectance images
S <- 0.85 + matrix(rnorm(ncell(r0), 0, 0.03), nrow = nrow(r0), ncol = ncol(r0))
S <- pmax(0.20, pmin(1.20, S))

# Derive NIR and Red that are consistent with NDVI:
# NDVI = (NIR - Red) / (NIR + Red)  ->  NIR = S*(1+NDVI)/2, Red = S*(1-NDVI)/2
nir_mat <- S * (1 + ndvi_mat) / 2
red_mat <- S * (1 - ndvi_mat) / 2

# Blue band (optional structure)
blue_mat <- 0.18 + 0.06 * water_bump + matrix(rnorm(ncell(r0), 0, 0.02), nrow = nrow(r0), ncol = ncol(r0))

# Write to rasters
blue <- r0; values(blue) <- as.vector(blue_mat)
red  <- r0; values(red)  <- as.vector(red_mat)
nir  <- r0; values(nir)  <- as.vector(nir_mat)

img <- c(blue, red, nir)
names(img) <- c("blue", "red", "nir")

# Compute NDVI (now it will have more pixels in classes 1 and 4)
ndvi <- (img$nir - img$red) / (img$nir + img$red)
names(ndvi) <- "ndvi"

plot(ndvi)

###############################################################################
# 2) Create strata raster (e.g., land-cover classes) from NDVI + a bit of structure
###############################################################################
# Make 4 land-cover classes using NDVI thresholds (toy example):
# 1 = water/low veg, 2 = built/bare, 3 = cropland/grass, 4 = forest/high veg
lc <- classify(
  ndvi,
  rcl = matrix(c(
    -Inf, 0.10, 1,
    0.10, 0.25, 2,
    0.25, 0.45, 3,
    0.45,  Inf, 4
  ), ncol = 3, byrow = TRUE)
)
names(lc) <- "lulc"
plot(lc)

# Optional: set class labels for plotting/analysis
lc_levels <- data.frame(
  value = 1:4,
  class = c("Water/LowVeg", "Built/Bare", "Cropland/Grass", "Forest/HighVeg")
)
levels(lc) <- lc_levels

###############################################################################
# 3) Spatial stratified random sampling
###############################################################################
# number of points 
n_class <- 50

# terra::spatSample can do stratified sampling with "strata"
# Returns a SpatVector of points
pts <- spatSample(
  x = lc,
  size = n_class,
  method = "random",
  strata = TRUE,
  na.rm = TRUE,
  as.points = TRUE
)

plot(pts)

# Check how many samples per class
table(pts$class)

###############################################################################
# 4) Extract image values at sampled points and run a simple analysis
###############################################################################
# Extract band + NDVI values to points
vals <- terra::extract(c(img, ndvi), pts)

# Combine with class labels
df <- cbind(as.data.frame(pts)[, c("class"), drop = FALSE], vals) 

# Summarize NDVI by class (typical check of separability)
summary_tbl <- df %>%
  group_by(class) %>%
  summarise(
    n = n(),
    ndvi_mean = mean(ndvi, na.rm = TRUE),
    ndvi_sd   = sd(ndvi, na.rm = TRUE),
    .groups = "drop"
  )

print(summary_tbl)

# Plot NDVI distributions by class
ggplot(df, aes(x = class, y = ndvi)) +
  geom_boxplot(outlier.size = 0.6) +
  theme_bw() +
  labs(x = "Stratum (Land-cover class)", y = "NDVI",
       title = "NDVI by strata (from stratified random samples)") +
  theme(axis.text.x = element_text(angle = 20, hjust = 1))

###############################################################################
# 5) Optional: visualize strata map + sample locations
###############################################################################
# define 4 colours (one per class)
cols <- c("dodgerblue", "orange", "yellowgreen", "darkgreen")

plot(lc, main = "Land-cover strata (lulc)")
points(pts, pch = 16, cex = 0.8, col = cols[pts$class])

