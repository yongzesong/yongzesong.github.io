###############################################################################
# Spatial stratified random sampling example for remote sensing images (R)
# - Creates synthetic multi-band image (3 bands) + a land-cover strata raster
# - Draws stratified random samples (equal n per class)
# - Extracts image values at samples and summarizes by class
###############################################################################

# Packages
library(terra)
library(dplyr)
library(ggplot2)

set.seed(123)

# Packages
install.packages("geodata")   # if not installed
library(geodata)
library(terra)

###############################################################################
# 1) Download real remote sensing–based temperature data (WorldClim v2)
###############################################################################
# Monthly mean temperature (°C * 10)
tmean <- worldclim_global(var = "tavg", res = 10)  # 10 arc-min resolution

# Select one month (e.g. July)
tmean_july <- tmean[[7]]

plot(tmean_july, main = "WorldClim July Mean Temperature")

# Define a study area (example: Australia)
ext_aus <- ext(112, 154, -44, -10)
tmean_aus <- crop(tmean_july, ext_aus)
plot(tmean_aus, main = "July Mean Temperature (Australia)")


###############################################################################
# 2) Create strata raster from temperature (WorldClim tmean)
###############################################################################
# WorldClim tavg is in °C * 10 → convert to °C
tmean_c <- tmean_aus / 10
names(tmean_c) <- "tmean"

plot(tmean_c, main = "July Mean Temperature (°C) – Australia")

# Create 4 temperature strata using quantiles
qs <- quantile(values(tmean_c), probs = c(0, 0.25, 0.5, 0.75, 1), na.rm = TRUE)

lc <- classify(
  tmean_c,
  rcl = matrix(c(
    qs[1], qs[2], 1,
    qs[2], qs[3], 2,
    qs[3], qs[4], 3,
    qs[4], qs[5], 4
  ), ncol = 3, byrow = TRUE)
)

names(lc) <- "class"
plot(lc, main = "Temperature strata (4 classes)")

# Add class labels
lc_levels <- data.frame(
  value = 1:4,
  class = c("Cool", "Mild", "Warm", "Hot")
)
levels(lc) <- lc_levels

###############################################################################
# 3) Spatial stratified random sampling
###############################################################################
n_class <- 100

pts <- spatSample(
  x = lc,
  size = n_class,
  method = "random",
  strata = TRUE,
  na.rm = TRUE,
  as.points = TRUE
)

plot(pts)
table(pts$class)

###############################################################################
# 4) Extract temperature values and summarise by stratum
###############################################################################
vals <- terra::extract(tmean_c, pts)

df <- cbind(
  as.data.frame(pts)[, c("class"), drop = FALSE],
  vals
)

library(dplyr)

summary_tbl <- df %>%
  group_by(class) %>%
  summarise(
    n = n(),
    temp_mean = mean(tmean, na.rm = TRUE),
    temp_sd   = sd(tmean, na.rm = TRUE),
    .groups = "drop"
  )

print(summary_tbl)

# Boxplot (temperature by stratum)
library(ggplot2)

ggplot(df, aes(x = class, y = tmean)) +
  geom_boxplot(outlier.size = 0.6) +
  theme_bw() +
  labs(
    x = "Temperature stratum",
    y = "July Mean Temperature (°C)",
    title = "Temperature distributions by spatial strata"
  )


###############################################################################
# 5) Visualize strata map + sample locations
###############################################################################
cols <- c("steelblue", "gold", "orange", "firebrick")

plot(lc, main = "Temperature strata (Australia)")
points(pts, pch = 16, cex = 0.7, col = cols[pts$class])



